package edu.udel.team0.model;

public class Model {

}

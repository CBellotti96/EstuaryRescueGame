package edu.udel.team0.enums;

public class Direction {

}

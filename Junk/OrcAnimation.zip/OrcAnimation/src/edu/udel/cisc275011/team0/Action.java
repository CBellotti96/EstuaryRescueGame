package edu.udel.cisc275011.team0;

public enum Action {
	
	//The four actions (three main actions RUN, JUMP, and FIRE along with DIE)
	
	RUN ("Run", 10, "_forward"),
	JUMP ("Jump", 8, "_jump"),
	FIRE ("Fire", 4, "_fire"),
	DIE ("Die", 7, "_die");
	
	private String identifier;	//What am I called: "Run", "Jump", "Fire", "Die"
	private int frameCount;		//How many frames are in this animation
	private String imgPostfix;	//Image file postfix
	
	public String getIdentifier () {
		return this.identifier;
	}
	
	public int getFrameCount () {
		return this.frameCount;
	}
	
	public String getImgPostfix () {
		return this.imgPostfix;
	}
	
	private Action (String identifier, int frameCount, String imgPostfix) {
		this.identifier = identifier;
		this.frameCount = frameCount;
		this.imgPostfix = imgPostfix;
	}
	
	//Cycle through the three main actions in the following order: RUN, JUMP, then FIRE
	
	public static Action nextAction (Action action) {
		if (action.equals(RUN))
			return JUMP;
		else if (action.equals(JUMP))
			return FIRE;
		else if (action.equals(FIRE))
			return RUN;
		else
			return action;
	}

}

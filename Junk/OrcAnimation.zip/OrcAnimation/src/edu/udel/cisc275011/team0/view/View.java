package edu.udel.cisc275011.team0.view;

import javax.swing.JComponent;

import edu.udel.cisc275011.team0.model.Model;

//This is the view class. The tick() and repaint() methods should be called from here.

public class View extends JComponent {
	
	private Model model;
	
	public final static int FRAME_WIDTH = 500;
	public final static int FRAME_HEIGHT = 300;
	public final static int IMG_WIDTH = 165;
	public final static int IMG_HEIGHT = 165;
	
	public View (Model model) {
		this.model = model;
	}

}

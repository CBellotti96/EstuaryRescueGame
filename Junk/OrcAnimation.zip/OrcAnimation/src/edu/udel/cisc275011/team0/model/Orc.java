package edu.udel.cisc275011.team0.model;

import edu.udel.cisc275011.team0.Action;
import edu.udel.cisc275011.team0.Direction;
import edu.udel.cisc275011.team0.view.View;

public class Orc {
	
	private Direction direction;	//Which way am I going
	private Action action;			//What action am I doing
	private int picNum;				//Which image am I displaying
	private int xloc = 0;			//Where am I on the x-axis
	private int yloc = 0;			//Where am I on the y-axis
	private final int xIncr = 8;	//What is my x velocity
	private final int yIncr = 2;	//What is my y velocity
	
	public Direction getDirection () {
		return this.direction;
	}
	
	public Action getAction () {
		return this.action;
	}
	
	public int getPicNum () {
		return this.picNum;
	}
	
	public int getXloc () {
		return this.xloc;
	}
	
	public int getYloc () {
		return this.yloc;
	}
	
	public void setAction (Action action) {
		this.action = action;
	}
	
	//The orc constructor will choose a random direction and assign the run action
	
	public Orc (int xloc, int yloc) {
		this.direction = Direction.randomDirection();
		this.action = Action.RUN;
		this.picNum = 0;
		this.xloc = xloc;
		this.yloc = yloc;
	}
	
	//Update x and y coordinates and decide if a direction change is necessary
	
	public void tick () {
		//Update picnum, considering the frame count of the current action
		this.picNum = (this.picNum + 1) % this.action.getFrameCount();
	  	
		//Update coords, where dx and dy are either -1 or 1 depending on direction
	  	this.xloc = this.xIncr * this.direction.getDx();
	  	this.yloc = this.yIncr * this.direction.getDy();
	  	
	  	//Should I bounce off of a wall
	  	if (xloc <= 0 || xloc + View.IMG_WIDTH > View.FRAME_WIDTH)
	  		this.direction = Direction.getDirection(!direction.getLeft(), direction.getUp());	//Change x direction
	  	
	  	if (yloc <= 0 || yloc + View.IMG_HEIGHT > View.FRAME_HEIGHT)
	  		this.direction = Direction.getDirection(direction.getLeft(), !direction.getUp());	//Change y direction
	}
	
	//Cycle to the next action in the following order: RUN, JUMP, FIRE
	
	public void nextAction () {
		this.action = Action.nextAction(action);
	}

}

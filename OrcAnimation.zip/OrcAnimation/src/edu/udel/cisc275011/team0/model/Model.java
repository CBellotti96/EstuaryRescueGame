package edu.udel.cisc275011.team0.model;

public class Model {

}

package edu.udel.cisc275011.team0;

public class Action {
	
	//The four actions (three main actions RUN, JUMP, and FIRE along with DIE)
	
	public final static Action RUN = new Action("Run", 10, "_forward");
	public final static Action JUMP = new Action("Jump", 8, "_jump");
	public final static Action FIRE = new Action("Fire", 4, "_fire");
	public final static Action DIE = new Action("Die", 7, "_die");
	
	private String identifier;	//What am I called: "Run", "Jump", "Fire", "Die"
	private int frameCount;		//How many frames are in this animation
	private String imgPostfix;	//Image file postfix
	
	public String getIdentifier () {
		return this.identifier;
	}
	
	public int getFrameCount () {
		return this.frameCount;
	}
	
	public String getImgPostfix () {
		return this.imgPostfix;
	}
	
	public Action (String identifier, int frameCount, String imgPostfix) {
		this.identifier = identifier;
		this.frameCount = frameCount;
		this.imgPostfix = imgPostfix;
	}
	
	//Cycle through the three main actions in the following order: RUN, JUMP, then FIRE
	
	public static Action nextAction (Action action) {
		if (action.equals(RUN))
			return JUMP;
		else if (action.equals(JUMP))
			return FIRE;
		else if (action.equals(FIRE))
			return RUN;
		else
			return action;
	}

}

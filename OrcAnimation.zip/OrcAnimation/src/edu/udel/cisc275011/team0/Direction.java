package edu.udel.cisc275011.team0;

import java.util.Random;

public class Direction {
	
	//The four used directions, along with an array of the directions for selecting a random direction
	
	public final static Direction NORTHEAST = new Direction("ne", false, true, 1, -1, "_northeast");
	public final static Direction SOUTHEAST = new Direction("se", false, false, 1, 1, "_southeast");
	public final static Direction SOUTHWEST = new Direction("sw", true, false, -1, 1, "_southwest");
	public final static Direction NORTHWEST = new Direction("nw", true, true, -1, -1, "_northwest");
	private final static Direction[] directions = {NORTHEAST, SOUTHEAST, SOUTHWEST, NORTHWEST};

	private String identifier;	//"ne", "se", "sw", "nw"; only for debugging purposes
	private boolean left;		//x-axis directional flag
	private boolean up;			//y-axis directional flag
	private int dx;				//x-axis directional unit vector (-1 or 1)
	private int dy;				//y-axis directional unit vector (-1 or 1)
	private String postFix;		//Image file postfix
	
	public String getIdentifier () {
		return this.identifier;
	}
	
	public boolean getLeft () {
		return this.left;
	}
	
	public boolean getUp () {
		return this.up;
	}
	
	public int getDx () {
		return this.dx;
	}
	
	public int getDy () {
		return this.dy;
	}
	
	public String getPostfix () {
		return this.postFix;
	}
	
	public Direction (String identifier, boolean left, boolean up, int dx, int dy, String postFix) {
		this.identifier = identifier;
		this.left = left;
		this.up = up;
		this.dx = dx;
		this.dy = dy;
		this.postFix = postFix;
	}
	
	//Return a direction based on directional flags
	
	public static Direction getDirection (boolean left, boolean up) {
		if (up)
			if (left)
				return NORTHWEST;
			else
				return NORTHEAST;
		else
			if (left)
				return SOUTHWEST;
			else
				return SOUTHEAST;
	}
	
	//Return a random direction
	
	public static Direction randomDirection () {
		Random r = new Random();
		int n = r.nextInt(4);
		return directions[n];
	}
	
}
